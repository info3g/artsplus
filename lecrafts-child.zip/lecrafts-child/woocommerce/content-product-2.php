<?php
/**
 * The template for displaying product content within loops
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/content-product.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you (the theme developer).
 * will need to copy the new files to your theme to maintain compatibility. We try to do this.
 * as little as possible, but it does happen. When this occurs the version of the template file will.
 * be bumped and the readme will list any important changes.
 *
 * @see     http://docs.woothemes.com/document/template-structure/
 * @author  WooThemes
 * @package WooCommerce/Templates
 * @version 2.6.4
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

global $product;

// Ensure visibility
if ( empty( $product ) || ! $product->is_visible() ) {
	return;
}
?>

<div <?php post_class( 'card-item' ); ?>>
	<div class="product__inner">

		<?php
			/**
			 * woocommerce_before_shop_loop_item hook.
			 *
			 * @hooked woocommerce_template_loop_product_link_open - 10 : removed
			 */
			do_action( 'woocommerce_before_shop_loop_item' );
		?>

		<figure href="<?php the_permalink(); ?>" class="product__image">
			
			<?php 
				/**
				 * woocommerce_before_shop_loop_item_title hook.
				 *
				 * @hooked woocommerce_show_product_loop_sale_flash - 10
				 * @hooked woocommerce_template_loop_product_thumbnail - 10 : removed
				 */
				do_action( 'woocommerce_before_shop_loop_item_title' ); 
			 ?>
			
			<a href="<?php the_permalink(); ?>" class="image"><?php tokoo_template_loop_product_thumbnail_alt( 'shop_catalog' ); ?></a>

			<a href="<?php the_permalink(); ?>" class="detail-circle"><i class="simple-icon-magnifier"></i><em><?php esc_html_e( 'View Details', 'tokoo' ); ?></em></a>
			
			<div class="action-addon">
				<?php 
					if ( class_exists( 'YITH_WCQV' ) ) :
						$label = esc_html( get_option( 'yith-wcqv-button-label' ) );
						echo '<a href="#" class="yith-wcqv-button" data-product_id="' . get_the_ID() . '"><span class="tooltip">'.$label.'</span><i class="simple-icon-eye"></i></a>';
					endif;
				?>
				<?php 
					if ( class_exists( 'YITH_WCWL' ) ) :
						echo do_shortcode( '[yith_wcwl_add_to_wishlist label= ""]' ); 
					endif;
				?>
			</div>
		</figure>
		
		<div class="product__detail">
			<?php 

				/**
				 * woocommerce_shop_loop_item_title hook.
				 *
				 * @hooked woocommerce_template_loop_product_title - 10 : removed
				 */
				do_action( 'woocommerce_shop_loop_item_title' );
				tokoo_product_title();
				tokoo_product_category(); 
			?>

			<div class="product__action">
				<?php 
					/**
					 * woocommerce_after_shop_loop_item_title hook.
					 *
					 * @hooked woocommerce_template_loop_rating - 5
					 * @hooked woocommerce_template_loop_price - 10
					 */
					do_action( 'woocommerce_after_shop_loop_item_title' );

					/**
					 * woocommerce_after_shop_loop_item hook.
					 *
					 * @hooked woocommerce_template_loop_product_link_close - 5 : removed
					 * @hooked woocommerce_template_loop_add_to_cart - 10
					 */
					do_action( 'woocommerce_after_shop_loop_item' );
				?>
			</div>
		</div>
	</div>

</div>
